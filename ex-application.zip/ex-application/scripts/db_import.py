# Copyright 2018 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except
# in compliance with the License. A copy of the License is located at
#
# https://aws.amazon.com/apache-2-0/
#
# or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
# specific language governing permissions and limitations under the License.
import csv
import os
import sqlite3
import logging

logging.basicConfig(level=logging.DEBUG)

# remove and recreate the database with every run
logging.info("Removing movies.db")
try:
    os.remove("movies.db")
except OSError:
    pass

conn = sqlite3.connect('movies.db')
c = conn.cursor()

# Create table
logging.info("Creating base table")
c.execute('''CREATE TABLE base
             (userId int, movieId int, rating int, timestamp int)''')

logging.info("Populating base table")
with open('./ml-100k/ua.base', 'r') as f:
    samples = csv.reader(f, delimiter='\t')
    for userId, movieId, rating, timestamp in samples:
        c.execute("""INSERT INTO base (userId, movieId, rating, timestamp)
                     VALUES (?,?,?,?)""",
                  (userId, movieId, rating, timestamp))


# Create table
logging.info("Creating user table")
c.execute('''CREATE TABLE user
             (userId int, age int, gender text, occupation text, zipcode text)''')

logging.info("Populating user table")
with open('./ml-100k/u.user', 'r') as f:
    reader = csv.reader(f, delimiter='|')
    for userId, age, gender, occupation, zipcode in reader:
        c.execute("""INSERT INTO user (userId, age, gender, occupation, zipcode)
                     VALUES (?,?,?,?,?)""",
                  (userId, age, gender, occupation, zipcode))

# Create table
logging.info("Creating item table")
c.execute('''CREATE TABLE item
             (movieId int,
             movieTitle text,
             releaseDate text,
             videoReleaseDate text,
             imdbURL text,
             unknown int,
             action int,
             adventure int,
             animation int,
             childrens int,
             comedy int,
             crime int,
             documentary int,
             drama int,
             fantasy int,
             filmnoir int,
             horror int,
             musical int,
             mystery int,
             romance int,
             scifi int,
             thriller int,
             war int,
             western int)''')

logging.info("Populating item table")
with open('./ml-100k/u.item', 'r', encoding="ISO-8859-1") as f:
    reader = csv.reader(f, delimiter='|')
    for movieId, movieTitle, releaseDate, videoReleaseDate, imdbURL, unknown, action, adventure, animation, childrens, comedy, crime, documentary, drama, fantasy, filmnoir, horror, musical, mystery, romance, scifi, thriller, war, western in reader:
        c.execute("""INSERT INTO item (movieId, movieTitle, releaseDate, videoReleaseDate, imdbURL, unknown, action, adventure, animation, childrens, comedy, crime, documentary, drama, fantasy, filmnoir, horror, musical, mystery, romance, scifi, thriller, war, western)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                  (movieId, movieTitle, releaseDate, videoReleaseDate, imdbURL, unknown, action, adventure, animation, childrens, comedy, crime, documentary, drama, fantasy, filmnoir, horror, musical, mystery, romance, scifi, thriller, war, western))


conn.commit()
conn.close()
